import { Directive, Input, ElementRef, HostListener } from '@angular/core';

@Directive({
    selector: '[imgSrc]',
    host: {
        '[src]': 'checkPath(src)',
        '(error)': 'onError()',
        '(load)': 'onLoad()'
    }
})
export class DefaultImage { 
    @Input() src: string;
	//@Input() defaultImg: string;
	//@Input() originalImg: string;
    errorImg: string;
	constructor(private el: ElementRef) {
       /* var temp = this;
         setTimeout(function(){
        temp.loadNewImage(this.originalImg);
        },1000);*/
    }
    /*
    @HostListener('mouseenter') onMouseEnter() {
        
        this.defaultImage(this.defaultImg);
    }
 
    @HostListener('mouseleave') onMouseLeave() {
        this.defaultImage(null);
    }
 */
 
 /*
    public loadNewImage(url) {
        console.log("new image function...............");
        var img = new Image();
        img.src = url;
        console.log(this.originalImg);
        img.onload = function() {
            console.log("new image load...............");
            
          // var temp = this;
            setTimeout(function(){
              //  temp.src = url;
                 //this.el.nativeElement.style.src = url;
                 //this.el.nativeElement.style.backgroundColor = "red";
           },1000)
        }
    }
    
    private defaultImage(defImg: string) {
        //alert(defImg)
		this.errorImg = defImg;
	}
    public onError() {
        return this.errorImg;
    }
    public onLoad() {
        //console.log("--------------"); 
        //console.log(this.originalImg);
        //console.log("--------------"); 
        var temp = this;
        if(this.src!=this.originalImg) {
            console.log("SRC - "+this.src);
            console.log("Original - "+this.originalImg);
           // this.loadNewImage(this.originalImg);
        }
        setTimeout(function(){
            //temp.src = this.errorImg;
            //temp.src = this.errorImg;
        },1000)
        
    }
    public checkPath(src) {
        return src ? src : this.errorImg;
    }
    */
}
/*
import { Directive, ElementRef, HostListener } from '@angular/core';
 
@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective {
  constructor(private el: ElementRef) { }
 
  @HostListener('mouseenter') onMouseEnter() {
    this.highlight('yellow');
  }
 
  @HostListener('mouseleave') onMouseLeave() {
    this.highlight(null);
  }
 
  private highlight(color: string) {
     //alert(color)
    this.el.nativeElement.style.backgroundColor = color;
  }
}
*/