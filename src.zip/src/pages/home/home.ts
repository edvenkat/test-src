import { Component, ViewChild  } from '@angular/core';
import { NavController, Platform, Slides, Events, FabContainer, Content, LoadingController,ToastController  } from 'ionic-angular';
import { AppRate } from '@ionic-native/app-rate';
import {  AdMobFree, AdMobFreeBannerConfig } from '@ionic-native/admob-free';


import { DetailsPage } from '../details/details';
import { ListPage } from '../list/list';
import { Search } from '../search/search';
import { User } from '../user/user';
import { DefaultImage } from '../../app/not.found'

import { WebService } from '../../providers/web-service';

@Component({
    selector: 'page-home',
    templateUrl: 'home.html'
})
export class HomePage {
    @ViewChild('mySliderH') sliderh : Slides;
    @ViewChild('mySliderC') sliderc : Slides;
    //@ViewChildren('mySliderC') slides: QueryList<ElementRef>;
    @ViewChild(Content) content: Content;
    selectedSegment: any;
    slidersHeader: any;
    slidersContent: any;
    imageUrls: any;
    showRightButton = true;
    showLeftButton = true;
    fabMenuActive = false;
    inifinteScrollForSlide1 = true;
    inifinteScrollForSlide2 = false;
    list:any;
    ngAfterViewInit() {
         this.sliderc.autoHeight = true;
        
     }
    
ionViewDidLoad() {
          
        }
        
        
   createBanner(){
        let toast = this.toastCtrl.create({
            message: 'Creating your ad',
            duration: 3000,
            position: 'top'
        });
        toast.present();
        const bannerConfig: AdMobFreeBannerConfig = {
            id: 'ca-app-pub-3940256099942544/6300978111',
            //isTesting: true,
            autoShow: true
        };
        this.adMobFree.banner.config(bannerConfig);

        this.adMobFree.banner.prepare()
        .then(() => {
            // banner Ad is ready
            // if we set autoShow to false, then we will need to call the show method here
        })
        .catch(e => console.log(e));
    }
    showInterstitial() {
		let toast = this.toastCtrl.create({
            message: 'Creating your Interstitial',
            duration: 3000,
            position: 'top'
        });
        toast.present();
   
        this.adMobFree.interstitial.config({
          id: 'ca-app-pub-3940256099942544/1033173712',
		  //isTesting: true,
          autoShow: true
        });
        this.adMobFree.interstitial.prepare();
    }
        
      
    constructor(public navCtrl: NavController,public events: Events,public loadingCtrl: LoadingController,private appRate: AppRate,public platform: Platform,private toastCtrl: ToastController, private adMobFree: AdMobFree,public webService: WebService) {
        var admobid = { // for iOS
			  banner: 'ca-app-pub-3940256099942544/6300978111',
              interstitial:'ca-app-pub-3940256099942544/1033173712',
              rewardedVideo:'ca-app-pub-3940256099942544/5224354917',
              nativeAdvanced:'ca-app-pub-3940256099942544/2247696110',
              nativeExpress:'ca-app-pub-3940256099942544/2793859312'
			};
       
    platform.ready().then(() => {
		//this.createBanner();
		//this.showInterstitial();
        this.webService.getHomePageContent()
    });

        

    //,private admob: AdMobPro
       /*var admobid = { // for iOS
			  banner: 'ca-app-pub-3940256099942544/6300978111',
              interstitial:'ca-app-pub-3940256099942544/1033173712',
              rewardedVideo:'ca-app-pub-3940256099942544/5224354917',
              nativeAdvanced:'ca-app-pub-3940256099942544/2247696110',
              nativeExpress:'ca-app-pub-3940256099942544/2793859312'
			};
            */
            
        //this.onClick();
        // or, override the whole preferences object
        this.appRate.preferences = {
          usesUntilPrompt: 3,
          storeAppURL: {
           ios: '',
           android: 'https://play.google.com/store/apps/details?id=com.lenovo.anyshare.gps',
           windows: ''
          }
        };
        this.appRate.promptForRating(true);
        
        
        
        this.events.subscribe('slidechange:tabSelected', eventData => { 
            const selectedIndex = this.slidersHeader.findIndex((slide) => {
                return slide.id === eventData;
            });
            this.sliderc.slideTo(selectedIndex);
            this.sliderh.slideTo(selectedIndex);
        });
        this.selectedSegment = { id: 1, title: "title 1"};
        this.imageUrls = [
            {"url":"assets/imgs/banner_04.jpg"},
            {"url":"assets/imgs/bjork-live.jpg"},
            {"url":"assets/imgs/card-saopaolo.png"}
        ];

        this.slidersHeader = [
            {
                id: 1,
                title: "title 1"
            },
            {
                id: 2,
                title: "title 2"
            },
            {
                id: 3,
                title: "title 3"
            },
            {
                id: 4,
                title: "title 4"
            },
            {
                id: 5,
                title: "title 5"
            }
            
        ]
        /*
        ,
            {
                id: 6,
                title: "title 6"
            },
            {
                id: 7,
                title: "title 7"
            },
            {
                id: 8,
                title: "title 8"
            },
            {
                id: 9,
                title: "title 9"
            },
            {
                id: 10,
                title: "title 10"
            }
        ];
*/      this.list = [{"songTitle":"1. test  – test test test in test","songCreated":"test test, test test, test test, test, test test 19, 2018","songImage":"http://www.lyricsintamil.com/wp-content/uploads/2016/05/2-5-64x64.jpg","songView":"10","songComments":"30"},{"songTitle":"2. test  – test test test in test","songCreated":"test test, test test, test test, test, test test 19, 2018","songImage":"assets/imgs/bjork-live.png","songView":"10","songComments":"30"},{"songTitle":"3. test  – test test test in test","songCreated":"test test, test test, test test, test, test test 19, 2018","songImage":"assets/imgs/bjork-live.png","songView":"10","songComments":"30"},{"songTitle":"4. test  – test test test in test","songCreated":"test test, test test, test test, test, test test 19, 2018","songImage":"assets/imgs/bjork-live.png","songView":"10","songComments":"30"},{"songTitle":"5. test  – test test test in test","songCreated":"test test, test test, test test, test, test test 19, 2018","songImage":"assets/imgs/bjork-live.png","songView":"10","songComments":"30"}];


      
        
        const loadersr = this.loadingCtrl.create({
            content: "Please wait..."
        });
        loadersr.present();
        var temp = this;
        setTimeout(function(){
            loadersr.dismiss();
            
              temp.slidersContent = [
            {"sliderId":1,"sliderName":"Latest Poster","list":[{"songTitle":"1. test  – test test test in test","songCreated":"test test, test test, test test, test, test test 19, 2018","songImage":"http://www.lyricsintamil.com/wp-content/uploads/2016/05/2-5-64x64.jpg","songView":"10","songComments":"30"},{"songTitle":"2. test  – test test test in test","songCreated":"test test, test test, test test, test, test test 19, 2018","songImage":"assets/imgs/bjork-live.png","songView":"10","songComments":"30"},{"songTitle":"3. test  – test test test in test","songCreated":"test test, test test, test test, test, test test 19, 2018","songImage":"assets/imgs/bjork-live.png","songView":"10","songComments":"30"},{"songTitle":"4. test  – test test test in test","songCreated":"test test, test test, test test, test, test test 19, 2018","songImage":"assets/imgs/bjork-live.png","songView":"10","songComments":"30"},{"songTitle":"5. test  – test test test in test","songCreated":"test test, test test, test test, test, test test 19, 2018","songImage":"assets/imgs/bjork-live.png","songView":"10","songComments":"30"}]},
            
            {"sliderId":2,"sliderName":"Actor","list":[{"name":"Actor 1"},{"name":"Actor 2"},{"name":"Actor 3"},{"name":"Actor 1"},{"name":"Actor 2"},{"name":"Actor 3"},{"name":"Actor 1"},{"name":"Actor 2"},{"name":"Actor 3"},{"name":"Actor 1"},{"name":"Actor 2"},{"name":"Actor 3"},{"name":"Actor 1"},{"name":"Actor 2"},{"name":"Actor 3"},{"name":"Actor 1"},{"name":"Actor 2"},{"name":"Actor 3"},{"name":"Actor 1"},{"name":"Actor 2"},{"name":"Actor 3"},{"name":"Actor 1"},{"name":"Actor 2"},{"name":"Actor 3"}]},
            
            
            {"sliderId":3,"sliderName":"Actress","list":[{"name":"Actress 1"},{"name":"Actress 2"},{"name":"Actress 3"}]},
            
            {"sliderId":4,"sliderName":"Movie","list":[{"name":"Movie 1"},{"name":"Movie 2"},{"name":"Movie 3"}]},
            
            {"sliderId":5,"sliderName":"Music","list":[{"name":"Music 1"},{"name":"Music 2"},{"name":"Music 3"}]},
        ];
        
        },1500)
    
    
    }
    
    goToPage(pagename) {
        if(pagename=="details")
            this.navCtrl.push(DetailsPage);
        if(pagename=="list")
            this.navCtrl.push(ListPage);
    }
    getSearch(fab: FabContainer) {
        fab.close();
        this.fabMenuActive = false;
        this.navCtrl.push(Search);
    }
    getUser(fab: FabContainer) {
        fab.close();
        this.fabMenuActive = false;
        this.navCtrl.push(User);
    }
    fabMenuToggle() {
        console.log("came");
        this.fabMenuActive = !this.fabMenuActive;
    }
    claseFabMenu(fab: FabContainer) {
        fab.close();
         this.fabMenuActive = !this.fabMenuActive;
    }
    redirectionPage(pageName:String,fab: FabContainer) {
         console.log("page redirection");
        fab.close();
    }
    scrollToTop(slider) {
        this.content.scrollToTop();
        console.log("slide"+slider.getActiveIndex())
        if(slider.getActiveIndex()==0) {
            this.inifinteScrollForSlide1 = true;
            this.inifinteScrollForSlide2 = false;
        } else if(slider.getActiveIndex()==1) {
            this.inifinteScrollForSlide1 = false;
            this.inifinteScrollForSlide2 = true;
        } else {
            this.inifinteScrollForSlide1 = false;
            this.inifinteScrollForSlide2 = false;
        }
      }
     AdjustHeight() {
       /* var list = document.getElementsByClassName("swiper-wrapper");
        console.log(list);
        console.log(list[1].clientHeight);
        console.log(list[1].style.height);
        list[1].style.height = (list[1].clientHeight * 2 ) + "px"
        */
    }
    
    getTest1(infiniteScroll?: any) {
        console.log("------------------- Test 1 called ------------------");
        var test=[{"songTitle":"6. test  – test test test in test","songCreated":"test test, test test, test test, test, test test 19, 2018","songImage":"assets/imgs/bjork-live.png","songView":"10","songComments":"30"},{"songTitle":"7. test  – test test test in test","songCreated":"test test, test test, test test, test, test test 19, 2018","songImage":"assets/imgs/bjork-live.png","songView":"10","songComments":"30"},{"songTitle":"8. test  – test test test in test","songCreated":"test test, test test, test test, test, test test 19, 2018","songImage":"assets/imgs/bjork-live.png","songView":"10","songComments":"30"},{"songTitle":"9. test  – test test test in test","songCreated":"test test, test test, test test, test, test test 19, 2018","songImage":"assets/imgs/bjork-live.png","songView":"10","songComments":"30"},{"songTitle":"10. test  – test test test in test","songCreated":"test test, test test, test test, test, test test 19, 2018","songImage":"assets/imgs/bjork-live.png","songView":"10","songComments":"30"}];
        //
        for(let i=0;i<test.length;i++) {
            console.log(test[i]);
            //this.slidersContent[0].list.push(test[i]);
            this.list.push(test[i]);
        }
        //
        console.log(this.slidersContent[0]);
        if(infiniteScroll) {
            setTimeout(function(){
                infiniteScroll.complete();
                 //this.sliderc.update();
            },2000);
        }
        this.AdjustHeight()
    }
    getTest2(infiniteScroll?: any) {
         if(infiniteScroll) {
            setTimeout(function(){
                infiniteScroll.complete();
            },2000);
        }
        console.log("------------------- Test 2 called ------------------");
    }
	
    onHeaderSlideChanged(slider) {
       //const currentSlide = this.slidersContent[slider.getActiveIndex()];
      // this.selectedSegment = currentSlide.id;
       //this.sliderc.slideTo(currentSlide);
    }
    
    onContentSlideChanged(slider) {
        const currentSlide = this.slidersHeader[slider.getActiveIndex()];
        if(typeof(currentSlide)!="undefined") {
            this.selectedSegment = currentSlide;
            this.sliderh.slideTo(slider.getActiveIndex());
            //this.content.scrollToTop();
        }
        
    }
    
    onSegmentChanged(segmentButton) {
        const selectedIndex = this.slidersContent.findIndex((slide) => {
            return slide.sliderId === segmentButton.id;
        });
        this.sliderc.slideTo(selectedIndex);
    }
    
    slideNext() {
         this.sliderh.slideNext();
    }
    
    slidePrev() {
         this.sliderh.slidePrev();
    }
    resSearch() {
        this.createBanner();
        this.showInterstitial();
        this.navCtrl.push(DetailsPage);
    }
   
}
