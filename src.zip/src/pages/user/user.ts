import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import {  OnInit } from '@angular/core';

@Component({
  selector: 'page-user',
  templateUrl: 'user.html'
})
export class User implements OnInit { 
	user : FormGroup;
    submitted = false;
	constructor(public navCtrl: NavController,
				public navParams: NavParams) {    
	    
        
    }
    sendDetails() {
        console.log(this.user);
        console.log(this.user.status);
        if(this.user.status==="INVALID") {
            console.log("came");
            this.submitted = true;
        }
        if(this.user.status==="VALID") {
            console.log("Movie Name -" + this.user.value.movieName);
            console.log("Song Name -" + this.user.value.songName);
            console.log("Comments -" + this.user.value.comments);
            
            this.user.reset();
        }
        
        
    
    }
	ionViewWillEnter() {  
		
	}
    ngOnInit() {
         this.user = new FormGroup({
            movieName : new FormControl('', Validators.required),
            songName  : new FormControl('', Validators.required),
            comments  : new FormControl('')
        });
        
    }
}